#
import math

aa = [1,2,3,4,5]

print(aa[2:len(aa)])