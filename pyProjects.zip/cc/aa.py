import re


# texthead = re.split(r"\n+", '')
#
# texthead[1][2:]
url_info = 'https://cn.investing.com'

url_info = url_info.replace('https://cn.', 'https://www.')

print(url_info)

